function mat_rand(r)
r.mark
if r.is_bord('w') && r.is_bord('o')
    up(r)
end
 zakr_up(r)
  if r.is_bord('n')
      if r.is_mark
      right(r)
      elseif ~r.is_mark
          r.step('o')
          right(r)
      end
  end
 d_left(r)
 zakr_up(r)
 
end


function d_left(r)
while ~ r.is_bord('w')
    r.step('w')
end
if r.is_mark
    down(r)
elseif ~r.is_mark
    r.step('s')
     down(r)
end
end


function zakr_up(r)
while ~ r.is_bord('n')
  right(r)
 perexod_left(r)
  left(r)
  if ~r.is_bord('n')
   perexod_right(r)
  end
 
end
end
function perexod_left(r)
if ~r.is_bord('w')
if r.is_mark==0
    r.step('n')
    r.mark
elseif r.is_mark==1
    r.step('n')
    r.step('w')
    r.mark
end 
elseif r.is_bord('w')
    r.step('n')
end
end
function perexod_right(r)
if ~r.is_bord('o')
if r.is_mark==0
    r.step('n')
    r.mark
elseif r.is_mark==1
    r.step('n')
    r.step('o')
    r.mark
end 
elseif r.is_bord('w')
    r.step('n')
end
end
function right(r)
while ~ r.is_bord('o')
    r.step('o')
    if  ~ r.is_bord('o')
     r.step('o') 
    r.mark
    end
end    
end
function left(r)
while ~ r.is_bord('w')
    r.step('w')
    if  ~ r.is_bord('w')
     r.step('w') 
    r.mark
    end
end      
end
function up(r)
while ~ r.is_bord('n')
    r.step('n')
    if  ~ r.is_bord('n')
     r.step('n') 
    r.mark
    end
end    
end
function down(r)
while ~ r.is_bord('s')
    r.step('s')
    if  ~ r.is_bord('s')
     r.step('s') 
    r.mark
    end
end    
end