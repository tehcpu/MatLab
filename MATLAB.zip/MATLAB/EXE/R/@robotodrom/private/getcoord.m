function [i,j,ni,nj,dx,dy]=getcoord(rd,side,num)
%[i,j,ni,nj,dx,dy]=getinf(rd,tred,com,i) - is metod of class ROBOTODROM
%[num]  - numer of robot  
%side= 'N'|'n'|'S'|'s'|'O'|'o'|'W'|'w'  

hr=rd.hrbt(1,num);
color=get(hr,'facecolor');
if color==rd.ycolor
    return
elseif color==[1 1 1] %([1 1 1]<->'w')
    error('FATAL ERROR')
end
%
dx=0;
dy=0;
d=rd.diam;
switch side
case {'N' 'n'}
    dy=d;
case {'S' 's'}
    dy=-d;
case {'O' 'o'}
    dx=d;
case {'W' 'w'}
    dx=-d;
otherwise
    error('required: side= ''N'' | ''n'' | ''S'' | ''s'' | ''O'' | ''o'' | ''W'' | ''w''   (step(rd,nn,napr,com))')
    return
end
%vychislenie indeksov tekuschey i sleduyuschey  kletok
x=get(rd.hrbt(1,num),'xdata');
y=get(rd.hrbt(1,num),'ydata');
j=ceil(max(x)/rd.diam);
i=ceil(max(y)/rd.diam);
ni=i+sign(dy);
nj=j+sign(dx);