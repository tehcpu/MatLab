addpath ([cd '\exe\r'])	
addpath ([cd '\exe\r\start'])	
addpath ([cd '\exe\g'])
addpath ([cd '\exe\g\start'])
