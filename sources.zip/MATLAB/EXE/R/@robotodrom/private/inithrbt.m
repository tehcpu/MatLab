function rd=inithrbt(rd)
%metod of class ROBOTODROM
%rd=createrbt(rd)

set(rd.hsqr,'ButtonDownFcn','setstart')
pause on
pause%ogidanie startovoy ustanovki robotov (callback setstart
rd=get(gcf,'userdata');
set(rd.hsqr,'ButtonDownFcn','')
set(rd.hrbt,'ButtonDownFcn','')
if length(rd.hrbt(1,:))==1
    set(gcf,'name','����� �� ��������� ����')
elseif length(rd.hrbt(1,:))>1
    set(gcf,'name','������ �� ��������� ����')
end


function setstart
%robotodrom --> setstart (buttondownfcn)
hs=gco;
if isequal(get(hs,'facecolor'),[0 0 0])
    return
end
hf=gcf;
rd=get(hf,'userdata');
num=get(hs,'userdata');
x=get(hs,'xdata');
d=x(2)-x(1);
if isempty(num)
    try
        num=length(rd.hrbt(1,:))+1;  %***************
    catch
        num=1;
    end
    set(hs,'userdata',num);
    hr=robot(hs,d,num);
    rd.hrbt=[rd.hrbt hr(:)];%*******
    set(hf,'userdata',rd)
else
    hr=rd.hrbt(:,num);
    set(hr,'erasemode','normal')
    delete(hr)
    rd.hrbt(:,num)=[];      %**************
    set(hf,'userdata',rd)
    renumerat(rd,num)       %*************
    set(hs,'userdata',[])
end 



function renumerat(rd,num)
%robotodrom --> setstart (buttondownfcn) --> renumerat
%global hsqr
%hrbt=get(gcf,'userdata');
d=rd.diam;
for hr=rd.hrbt(:,num:end)
    rnum=str2num(get(hr(6),'string'));
    if rnum>num        
        set(hr(6),'string',num2str(rnum-1))
        i=ceil(max(get(hr(1),'ydata'))/d);
        j=ceil(max(get(hr(1),'xdata'))/d);
        s=get(rd.hsqr(i,j),'userdata');
        set(rd.hsqr(i,j),'userdata',rnum-1)
    end
end



function hr=robot(hs,d,num)
%robotodrom --> setstart (buttondownfcn) --> robot
%r=robot(hs,d,num)
%where
%hs - head of squares
%d - diametr of square
%num - numer of robot

i=ceil(max(get(hs,'ydata'))/d);
j=ceil(max(get(hs,'xdata'))/d);
fi=0:0.1:6.3;
xR=(cos(fi)*.28+j-0.5)*d;
yR=(sin(fi)*.28+i-0.5)*d;
xN=-[.6 .4 .4 .6];
yN=-[.03 .03 .2 .2];
xN=(j+xN)*d;
yN=(i+yN)*d;
xS=-[.6 .4 .4 .6];
yS=-[.97 .97 .8 .8];
xS=(j+xS)*d;
yS=(i+yS)*d;
xO=-[.2 .03 .03 .2];
yO=-[.6 .6 .4 .4];
xO=(j+xO)*d;
yO=(i+yO)*d;
xW=-[.97 .8 .8 .97];
yW=-[.6 .6 .4 .4];
xW=(j+xW)*d;
yW=(i+yW)*d;
%
hr(1)=patch(xR,yR,'r','erasemode','background');
hr(2)=patch(xN,yN,'w','erasemode','background');
hr(3)=patch(xS,yS,'w','erasemode','background');
hr(4)=patch(xO,yO,'w','erasemode','background');
hr(5)=patch(xW,yW,'w','erasemode','background');
hr(6)=text((j-.7)*d,(i-.5)*d,num2str(num));
set(hr(6),'color','k','erasemode','background')
set(hr(1),...
    'userdata',num,...
    'buttondownfcn','invcolor') %****************
hr=hr(:);



function invcolor
%setstart (buttondownfcn) --> robot --> invcolr (buttondownfcn)
hr=gco;
color=get(hr,'facecolor');
if isequal(color,[1 0 0])
    set(hr,'erasemode','normal')
    set(hr,'facecolor','y','userdata','y')
    set(hr,'erasemode','background')    
elseif isequal(color,[1 1 0])
    set(hr,'erasemode','normal')
    set(hr,'facecolor','r','userdata','r')
    set(hr,'erasemode','background')
end