function testpar(rd,side,num)
if max(size(num))>1
    error('max(size(num))>1')
elseif ~isa(num,'double') 
    error('~isa(num,''double'')')
end
if ~ismember(side,'NnSsOoWw')
    error('~ismember(side,''NnSsOoWw'')')
end
if ~isa(rd,'robotodrom')
    error('~isa(rd,''robotodrom'')')
end