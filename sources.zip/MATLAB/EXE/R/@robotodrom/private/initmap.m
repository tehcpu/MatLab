function rd=initmap(rd)
% metod of class ROBOTODROM
sqrcolor=get(gcf,'color');
if isempty(rd.map)%
    [m,n]=size(rd.hsqr);
    rd.map(1:m,1:n)='.';
    set(rd.hsqr,...
        'facecolor',sqrcolor,...
        'ButtonDownFcn','setcolor')
    if ismember('k',rd.maptype)%proverka nugnoli delaty "chernuyu ramky"
        rd.map([1 m],:)='k';
        rd.map(2:m-1,[1 n])='k';
        set(gcf,'userdata',rd)
        set(rd.hsqr([1 m],1:n),...
            'facecolor','k',...
            'buttondownfcn','')
        set(rd.hsqr(2:m-1,[1 n]),...
            'facecolor','k',...
            'buttondownfcn','')
    end
    newmap(rd)
    rd=get(gcf,'userdata');
else
    oldmap(rd)
end


function oldmap(rd)
%initmap --> oldmap
%disp(rd.map)
%disp('****')
[i,j]=find(rd.map=='k');   
ind=[i j]';
for in=ind
    set(rd.hsqr(in(1),in(2)),'facecolor','k')
end
[i,j]=find(rd.map=='m');
ind=[i j]';
for in=ind
    set(rd.hsqr(in(1),in(2)),'facecolor',rd.mcolor)
end



function newmap(rd)
%initmap --> newmap
pause on
set(gcf,'userdata',rd)
for i=1:length(rd.maptype)
    pause%ogidanie okonchaniya markerovki kletok (callback setcolor)
    rd=get(gcf,'userdata');
    rd.maptype=fliplr(rd.maptype);   
    set(gcf,'userdata',rd)
end    
set(rd.hsqr,'ButtonDownFcn','')
map=rd.map;
mapfile=rd.mapfile;
save(mapfile,'map')
    
    

function setcolor
%savemap --> setcolor (buttodownfcn)
rd=get(gcf,'userdata');
switch rd.maptype(1)
case 'm'
    color=rd.mcolor;
case 'k'
    color=[0 0 0];
end        
hs=gco;
y=get(hs,'ydata');
d=y(3)-y(2);
i=ceil(max(y)/d);
j=ceil(max(get(hs,'xdata'))/d);
if rd.map(i,j)==rd.maptype(1)
    set(hs,'facecolor',get(gcf,'color'))
    rd.map(i,j)='.';
elseif length(rd.maptype)==2
    if rd.map(i,j)~=rd.maptype(2)
        set(hs,'facecolor',color)
        rd.map(i,j)=rd.maptype(1);
    end
else
    set(hs,'facecolor',color)
    rd.map(i,j)=rd.maptype(1);
end   
set(gcf,'userdata',rd)
