function test(r)
while ~r.is_bord('s')
r.step('s')
end
while (~r.is_bord('w'))
r.step('w')
end
r.mark
while (~r.is_bord('n'))&&(~r.is_bord('w'))||(~r.is_bord('n'))&&(~r.is_bord('o'))
while (~r.is_bord('o'))
r.step('o')
r.mark
end
r.step('n')
r.mark
while (~r.is_bord('w'))
r.step('w')
r.mark
end
if (~r.is_bord('n'))
r.step('n')
r.mark
end
end